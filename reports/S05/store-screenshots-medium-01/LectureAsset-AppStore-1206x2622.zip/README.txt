Lecture Asset - App Store screenshot upload copies
1206 x 2622 RGB/sRGB PNG; no alpha.
en: English, zh-Hans: Simplified Chinese. Upload each language separately.
Use iPhone with Dynamic Island (medium display). Keep order01 through06.
Do not upload the ZIP or contact sheets as screenshots; extract PNG files first.
Frozen1320x2868 masters are unchanged. No ASC upload was performed.

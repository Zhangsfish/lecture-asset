# Lecture 2026-09-29

OCR below is an index. Inspect the linked JPEG before using a page for substantive or exact claims.

## Page 0001

![Page 0001](slides/0001.jpg)

OCR status: empty

```text

```

## Page 0002

![Page 0002](slides/0002.jpg)

OCR status: ok

```text
synthetic
```

## Page 0003

![Page 0003](slides/0003.jpg)

OCR status: failed

```text

```

## Page 0004

![Page 0004](slides/0004.jpg)

OCR status: empty

```text

```

## Page 0005

![Page 0005](slides/0005.jpg)

OCR status: ok

```text
synthetic
```

## Page 0006

![Page 0006](slides/0006.jpg)

OCR status: failed

```text

```

## Page 0007

![Page 0007](slides/0007.jpg)

OCR status: empty

```text

```

## Page 0008

![Page 0008](slides/0008.jpg)

OCR status: ok

```text
synthetic
```

## Page 0009

![Page 0009](slides/0009.jpg)

OCR status: failed

```text

```

## Page 0010

![Page 0010](slides/0010.jpg)

OCR status: empty

```text

```

## Page 0011

![Page 0011](slides/0011.jpg)

OCR status: ok

```text
synthetic
```

## Page 0012

![Page 0012](slides/0012.jpg)

OCR status: failed

```text

```

## Page 0013

![Page 0013](slides/0013.jpg)

OCR status: empty

```text

```

## Page 0014

![Page 0014](slides/0014.jpg)

OCR status: ok

```text
synthetic
```

## Page 0015

![Page 0015](slides/0015.jpg)

OCR status: failed

```text

```

## Page 0016

![Page 0016](slides/0016.jpg)

OCR status: empty

```text

```

## Page 0017

![Page 0017](slides/0017.jpg)

OCR status: ok

```text
synthetic
```

## Page 0018

![Page 0018](slides/0018.jpg)

OCR status: failed

```text

```

## Page 0019

![Page 0019](slides/0019.jpg)

OCR status: empty

```text

```

## Page 0020

![Page 0020](slides/0020.jpg)

OCR status: ok

```text
synthetic
```

## Page 0021

![Page 0021](slides/0021.jpg)

OCR status: failed

```text

```

## Page 0022

![Page 0022](slides/0022.jpg)

OCR status: empty

```text

```

## Page 0023

![Page 0023](slides/0023.jpg)

OCR status: ok

```text
synthetic
```

## Page 0024

![Page 0024](slides/0024.jpg)

OCR status: failed

```text

```

## Page 0025

![Page 0025](slides/0025.jpg)

OCR status: empty

```text

```

## Page 0026

![Page 0026](slides/0026.jpg)

OCR status: ok

```text
synthetic
```

## Page 0027

![Page 0027](slides/0027.jpg)

OCR status: failed

```text

```

## Page 0028

![Page 0028](slides/0028.jpg)

OCR status: empty

```text

```

## Page 0029

![Page 0029](slides/0029.jpg)

OCR status: ok

```text
synthetic
```

## Page 0030

![Page 0030](slides/0030.jpg)

OCR status: failed

```text

```

## Page 0031

![Page 0031](slides/0031.jpg)

OCR status: empty

```text

```

## Page 0032

![Page 0032](slides/0032.jpg)

OCR status: ok

```text
synthetic
```

## Page 0033

![Page 0033](slides/0033.jpg)

OCR status: failed

```text

```

## Page 0034

![Page 0034](slides/0034.jpg)

OCR status: empty

```text

```

## Page 0035

![Page 0035](slides/0035.jpg)

OCR status: ok

```text
synthetic
```

## Page 0036

![Page 0036](slides/0036.jpg)

OCR status: failed

```text

```

## Page 0037

![Page 0037](slides/0037.jpg)

OCR status: empty

```text

```

## Page 0038

![Page 0038](slides/0038.jpg)

OCR status: ok

```text
synthetic
```

## Page 0039

![Page 0039](slides/0039.jpg)

OCR status: failed

```text

```

## Page 0040

![Page 0040](slides/0040.jpg)

OCR status: empty

```text

```

## Page 0041

![Page 0041](slides/0041.jpg)

OCR status: ok

```text
synthetic
```

## Page 0042

![Page 0042](slides/0042.jpg)

OCR status: failed

```text

```

## Page 0043

![Page 0043](slides/0043.jpg)

OCR status: empty

```text

```

## Page 0044

![Page 0044](slides/0044.jpg)

OCR status: ok

```text
synthetic
```

## Page 0045

![Page 0045](slides/0045.jpg)

OCR status: failed

```text

```

## Page 0046

![Page 0046](slides/0046.jpg)

OCR status: empty

```text

```

## Page 0047

![Page 0047](slides/0047.jpg)

OCR status: ok

```text
synthetic
```

## Page 0048

![Page 0048](slides/0048.jpg)

OCR status: failed

```text

```

## Page 0049

![Page 0049](slides/0049.jpg)

OCR status: empty

```text

```

## Page 0050

![Page 0050](slides/0050.jpg)

OCR status: ok

```text
synthetic
```

## Page 0051

![Page 0051](slides/0051.jpg)

OCR status: failed

```text

```

## Page 0052

![Page 0052](slides/0052.jpg)

OCR status: empty

```text

```

## Page 0053

![Page 0053](slides/0053.jpg)

OCR status: ok

```text
synthetic
```

## Page 0054

![Page 0054](slides/0054.jpg)

OCR status: failed

```text

```

## Page 0055

![Page 0055](slides/0055.jpg)

OCR status: empty

```text

```

## Page 0056

![Page 0056](slides/0056.jpg)

OCR status: ok

```text
synthetic
```

## Page 0057

![Page 0057](slides/0057.jpg)

OCR status: failed

```text

```

## Page 0058

![Page 0058](slides/0058.jpg)

OCR status: empty

```text

```

## Page 0059

![Page 0059](slides/0059.jpg)

OCR status: ok

```text
synthetic
```

## Page 0060

![Page 0060](slides/0060.jpg)

OCR status: failed

```text

```

## Page 0061

![Page 0061](slides/0061.jpg)

OCR status: empty

```text

```

## Page 0062

![Page 0062](slides/0062.jpg)

OCR status: ok

```text
synthetic
```

## Page 0063

![Page 0063](slides/0063.jpg)

OCR status: failed

```text

```

## Page 0064

![Page 0064](slides/0064.jpg)

OCR status: empty

```text

```

## Page 0065

![Page 0065](slides/0065.jpg)

OCR status: ok

```text
synthetic
```

## Page 0066

![Page 0066](slides/0066.jpg)

OCR status: failed

```text

```

## Page 0067

![Page 0067](slides/0067.jpg)

OCR status: empty

```text

```

## Page 0068

![Page 0068](slides/0068.jpg)

OCR status: ok

```text
synthetic
```

## Page 0069

![Page 0069](slides/0069.jpg)

OCR status: failed

```text

```

## Page 0070

![Page 0070](slides/0070.jpg)

OCR status: empty

```text

```

## Page 0071

![Page 0071](slides/0071.jpg)

OCR status: ok

```text
synthetic
```

## Page 0072

![Page 0072](slides/0072.jpg)

OCR status: failed

```text

```

## Page 0073

![Page 0073](slides/0073.jpg)

OCR status: empty

```text

```

## Page 0074

![Page 0074](slides/0074.jpg)

OCR status: ok

```text
synthetic
```

## Page 0075

![Page 0075](slides/0075.jpg)

OCR status: failed

```text

```

## Page 0076

![Page 0076](slides/0076.jpg)

OCR status: empty

```text

```

## Page 0077

![Page 0077](slides/0077.jpg)

OCR status: ok

```text
synthetic
```

## Page 0078

![Page 0078](slides/0078.jpg)

OCR status: failed

```text

```

## Page 0079

![Page 0079](slides/0079.jpg)

OCR status: empty

```text

```

## Page 0080

![Page 0080](slides/0080.jpg)

OCR status: ok

```text
synthetic
```

## Page 0081

![Page 0081](slides/0081.jpg)

OCR status: failed

```text

```

## Page 0082

![Page 0082](slides/0082.jpg)

OCR status: empty

```text

```

## Page 0083

![Page 0083](slides/0083.jpg)

OCR status: ok

```text
synthetic
```

## Page 0084

![Page 0084](slides/0084.jpg)

OCR status: failed

```text

```

## Page 0085

![Page 0085](slides/0085.jpg)

OCR status: empty

```text

```

## Page 0086

![Page 0086](slides/0086.jpg)

OCR status: ok

```text
synthetic
```

## Page 0087

![Page 0087](slides/0087.jpg)

OCR status: failed

```text

```

## Page 0088

![Page 0088](slides/0088.jpg)

OCR status: empty

```text

```

## Page 0089

![Page 0089](slides/0089.jpg)

OCR status: ok

```text
synthetic
```

## Page 0090

![Page 0090](slides/0090.jpg)

OCR status: failed

```text

```

## Page 0091

![Page 0091](slides/0091.jpg)

OCR status: empty

```text

```

## Page 0092

![Page 0092](slides/0092.jpg)

OCR status: ok

```text
synthetic
```

## Page 0093

![Page 0093](slides/0093.jpg)

OCR status: failed

```text

```

## Page 0094

![Page 0094](slides/0094.jpg)

OCR status: empty

```text

```

## Page 0095

![Page 0095](slides/0095.jpg)

OCR status: ok

```text
synthetic
```

## Page 0096

![Page 0096](slides/0096.jpg)

OCR status: failed

```text

```

## Page 0097

![Page 0097](slides/0097.jpg)

OCR status: empty

```text

```

## Page 0098

![Page 0098](slides/0098.jpg)

OCR status: ok

```text
synthetic
```

## Page 0099

![Page 0099](slides/0099.jpg)

OCR status: failed

```text

```

## Page 0100

![Page 0100](slides/0100.jpg)

OCR status: empty

```text

```

## Page 0101

![Page 0101](slides/0101.jpg)

OCR status: ok

```text
synthetic
```

## Page 0102

![Page 0102](slides/0102.jpg)

OCR status: failed

```text

```

## Page 0103

![Page 0103](slides/0103.jpg)

OCR status: empty

```text

```

## Page 0104

![Page 0104](slides/0104.jpg)

OCR status: ok

```text
synthetic
```

## Page 0105

![Page 0105](slides/0105.jpg)

OCR status: failed

```text

```

## Page 0106

![Page 0106](slides/0106.jpg)

OCR status: empty

```text

```

## Page 0107

![Page 0107](slides/0107.jpg)

OCR status: ok

```text
synthetic
```

## Page 0108

![Page 0108](slides/0108.jpg)

OCR status: failed

```text

```

## Page 0109

![Page 0109](slides/0109.jpg)

OCR status: empty

```text

```

## Page 0110

![Page 0110](slides/0110.jpg)

OCR status: ok

```text
synthetic
```

## Page 0111

![Page 0111](slides/0111.jpg)

OCR status: failed

```text

```

## Page 0112

![Page 0112](slides/0112.jpg)

OCR status: empty

```text

```

## Page 0113

![Page 0113](slides/0113.jpg)

OCR status: ok

```text
synthetic
```

## Page 0114

![Page 0114](slides/0114.jpg)

OCR status: failed

```text

```

## Page 0115

![Page 0115](slides/0115.jpg)

OCR status: empty

```text

```

## Page 0116

![Page 0116](slides/0116.jpg)

OCR status: ok

```text
synthetic
```

## Page 0117

![Page 0117](slides/0117.jpg)

OCR status: failed

```text

```

## Page 0118

![Page 0118](slides/0118.jpg)

OCR status: empty

```text

```

## Page 0119

![Page 0119](slides/0119.jpg)

OCR status: ok

```text
synthetic
```

## Page 0120

![Page 0120](slides/0120.jpg)

OCR status: failed

```text

```

## Page 0121

![Page 0121](slides/0121.jpg)

OCR status: empty

```text

```

## Page 0122

![Page 0122](slides/0122.jpg)

OCR status: ok

```text
synthetic
```

## Page 0123

![Page 0123](slides/0123.jpg)

OCR status: failed

```text

```

## Page 0124

![Page 0124](slides/0124.jpg)

OCR status: empty

```text

```

## Page 0125

![Page 0125](slides/0125.jpg)

OCR status: ok

```text
synthetic
```

## Page 0126

![Page 0126](slides/0126.jpg)

OCR status: failed

```text

```

## Page 0127

![Page 0127](slides/0127.jpg)

OCR status: empty

```text

```

## Page 0128

![Page 0128](slides/0128.jpg)

OCR status: ok

```text
synthetic
```

## Page 0129

![Page 0129](slides/0129.jpg)

OCR status: failed

```text

```

## Page 0130

![Page 0130](slides/0130.jpg)

OCR status: empty

```text

```

## Page 0131

![Page 0131](slides/0131.jpg)

OCR status: ok

```text
synthetic
```

## Page 0132

![Page 0132](slides/0132.jpg)

OCR status: failed

```text

```

## Page 0133

![Page 0133](slides/0133.jpg)

OCR status: empty

```text

```

## Page 0134

![Page 0134](slides/0134.jpg)

OCR status: ok

```text
synthetic
```

## Page 0135

![Page 0135](slides/0135.jpg)

OCR status: failed

```text

```

## Page 0136

![Page 0136](slides/0136.jpg)

OCR status: empty

```text

```

## Page 0137

![Page 0137](slides/0137.jpg)

OCR status: ok

```text
synthetic
```

## Page 0138

![Page 0138](slides/0138.jpg)

OCR status: failed

```text

```

## Page 0139

![Page 0139](slides/0139.jpg)

OCR status: empty

```text

```

## Page 0140

![Page 0140](slides/0140.jpg)

OCR status: ok

```text
synthetic
```

## Page 0141

![Page 0141](slides/0141.jpg)

OCR status: failed

```text

```

## Page 0142

![Page 0142](slides/0142.jpg)

OCR status: empty

```text

```

## Page 0143

![Page 0143](slides/0143.jpg)

OCR status: ok

```text
synthetic
```

## Page 0144

![Page 0144](slides/0144.jpg)

OCR status: failed

```text

```

## Page 0145

![Page 0145](slides/0145.jpg)

OCR status: empty

```text

```

## Page 0146

![Page 0146](slides/0146.jpg)

OCR status: ok

```text
synthetic
```

## Page 0147

![Page 0147](slides/0147.jpg)

OCR status: failed

```text

```

## Page 0148

![Page 0148](slides/0148.jpg)

OCR status: empty

```text

```

## Page 0149

![Page 0149](slides/0149.jpg)

OCR status: ok

```text
synthetic
```

## Page 0150

![Page 0150](slides/0150.jpg)

OCR status: failed

```text

```

## Page 0151

![Page 0151](slides/0151.jpg)

OCR status: empty

```text

```

## Page 0152

![Page 0152](slides/0152.jpg)

OCR status: ok

```text
synthetic
```

## Page 0153

![Page 0153](slides/0153.jpg)

OCR status: failed

```text

```

## Page 0154

![Page 0154](slides/0154.jpg)

OCR status: empty

```text

```

## Page 0155

![Page 0155](slides/0155.jpg)

OCR status: ok

```text
synthetic
```

## Page 0156

![Page 0156](slides/0156.jpg)

OCR status: failed

```text

```

## Page 0157

![Page 0157](slides/0157.jpg)

OCR status: empty

```text

```

## Page 0158

![Page 0158](slides/0158.jpg)

OCR status: ok

```text
synthetic
```

## Page 0159

![Page 0159](slides/0159.jpg)

OCR status: failed

```text

```

## Page 0160

![Page 0160](slides/0160.jpg)

OCR status: empty

```text

```

## Page 0161

![Page 0161](slides/0161.jpg)

OCR status: ok

```text
synthetic
```

## Page 0162

![Page 0162](slides/0162.jpg)

OCR status: failed

```text

```

## Page 0163

![Page 0163](slides/0163.jpg)

OCR status: empty

```text

```

## Page 0164

![Page 0164](slides/0164.jpg)

OCR status: ok

```text
synthetic
```

## Page 0165

![Page 0165](slides/0165.jpg)

OCR status: failed

```text

```

## Page 0166

![Page 0166](slides/0166.jpg)

OCR status: empty

```text

```

## Page 0167

![Page 0167](slides/0167.jpg)

OCR status: ok

```text
synthetic
```

## Page 0168

![Page 0168](slides/0168.jpg)

OCR status: failed

```text

```

## Page 0169

![Page 0169](slides/0169.jpg)

OCR status: empty

```text

```

## Page 0170

![Page 0170](slides/0170.jpg)

OCR status: ok

```text
synthetic
```

## Page 0171

![Page 0171](slides/0171.jpg)

OCR status: failed

```text

```

## Page 0172

![Page 0172](slides/0172.jpg)

OCR status: empty

```text

```

## Page 0173

![Page 0173](slides/0173.jpg)

OCR status: ok

```text
synthetic
```

## Page 0174

![Page 0174](slides/0174.jpg)

OCR status: failed

```text

```

## Page 0175

![Page 0175](slides/0175.jpg)

OCR status: empty

```text

```

## Page 0176

![Page 0176](slides/0176.jpg)

OCR status: ok

```text
synthetic
```

## Page 0177

![Page 0177](slides/0177.jpg)

OCR status: failed

```text

```

## Page 0178

![Page 0178](slides/0178.jpg)

OCR status: empty

```text

```

## Page 0179

![Page 0179](slides/0179.jpg)

OCR status: ok

```text
synthetic
```

## Page 0180

![Page 0180](slides/0180.jpg)

OCR status: failed

```text

```

## Page 0181

![Page 0181](slides/0181.jpg)

OCR status: empty

```text

```

## Page 0182

![Page 0182](slides/0182.jpg)

OCR status: ok

```text
synthetic
```

## Page 0183

![Page 0183](slides/0183.jpg)

OCR status: failed

```text

```

## Page 0184

![Page 0184](slides/0184.jpg)

OCR status: empty

```text

```

## Page 0185

![Page 0185](slides/0185.jpg)

OCR status: ok

```text
synthetic
```

## Page 0186

![Page 0186](slides/0186.jpg)

OCR status: failed

```text

```

## Page 0187

![Page 0187](slides/0187.jpg)

OCR status: empty

```text

```

## Page 0188

![Page 0188](slides/0188.jpg)

OCR status: ok

```text
synthetic
```

## Page 0189

![Page 0189](slides/0189.jpg)

OCR status: failed

```text

```

## Page 0190

![Page 0190](slides/0190.jpg)

OCR status: empty

```text

```

## Page 0191

![Page 0191](slides/0191.jpg)

OCR status: ok

```text
synthetic
```

## Page 0192

![Page 0192](slides/0192.jpg)

OCR status: failed

```text

```

## Page 0193

![Page 0193](slides/0193.jpg)

OCR status: empty

```text

```

## Page 0194

![Page 0194](slides/0194.jpg)

OCR status: ok

```text
synthetic
```

## Page 0195

![Page 0195](slides/0195.jpg)

OCR status: failed

```text

```

## Page 0196

![Page 0196](slides/0196.jpg)

OCR status: empty

```text

```

## Page 0197

![Page 0197](slides/0197.jpg)

OCR status: ok

```text
synthetic
```

## Page 0198

![Page 0198](slides/0198.jpg)

OCR status: failed

```text

```

## Page 0199

![Page 0199](slides/0199.jpg)

OCR status: empty

```text

```

## Page 0200

![Page 0200](slides/0200.jpg)

OCR status: ok

```text
synthetic
```

